<!DOCTYPE html>
<html>
<head>
    <TITLE>Online Dart Game ,Developed By Ehsan Jelodar   </TITLE>
    <META charset="utf-8" />
    <meta name="robots" content="index,follow" />
    <meta name="keywords" content="Game, Dart, Dart Game">
    <meta name="description" content="Dart Game Developed by Ehsan Jelodar">
    <meta name="author" content="Ehsan Jelodar, Mail: Ehsan.Jolodar(-at-)gmail.com">

    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="style.min.css" >

    <script src="js/jq.js"></script>
    <script src="js/main.js"></script>

    <meta name="viewport" content="width=device-width,initial-scale=1">


    <!--[if lt IE 10]>
    <script>
        document.location.href = 'IE';
    </script>
    <![endif]-->

</head>
<body>
<div id="ej-popup-container"></div>
<div id="ej-popup" >
    <span id="ej-popup-close-btn"></span>
    <div id="ej-popup-html"></div>
</div>


    <div id="animation-div"><canvas height="602" width="602" id="animation-canvas"> your browser not support</canvas></div>
    <div id="high-score-container">
        <input id="high-score-btn" type="button" value="Rate">
    </div>
    <div id="start_btn_container">
      <select id="intensity_select">
          <option value="100">Easy</option>
          <option value="50">Medium</option>
          <option value="30">Hard</option>
      </select>
      <div id="Start_game_btn">Start Game</div>
    </div>

<div id="title_initial">
   <svg  height="200" width="600" >
      <text  x="1" y="125" style=" font-family: sans-serif; font-size:74px; stroke:red; stroke-width:4px;  stroke-linecap:round; stroke-dasharray:1;  fill:none;" >
        Online Dart Game
      </text>
    </svg>
</div>


    <div id="right-menu">

        <h1>Online Dart Game</h1>

        <h3>Instructions</h3>
        use dart to pop the balloons <br>
        move the mouse to control the direction of the dart, press the mouse button to shoot the dart.  <br>

        <div class="separator"></div>
        <div id="author">
        Developed By : <br>Ehsan Jelodar
        </div>
        <div class="separator"></div>

    </div>

    <div id="left-menu">
        <div id="right-menu-header">
            <h3>Info</h3>
        </div>

This game created with Artificial Intelligence (GA algorithm), balloons location need a algorithm for best performance and passable in all level of game, and prevent impossible state for continue game.<br>
        I find a GA algorithm  with 100% passable for pass all level of game.



    </div>




<footer class="">
    <div id="footer-text">
        &copy; <?php echo date("Y");?>
AllRights reserved by Ehsan Jelodar
</div>

</footer>

</body>
</html>
